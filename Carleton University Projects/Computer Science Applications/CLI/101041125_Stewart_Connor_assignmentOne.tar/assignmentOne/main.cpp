/*Name: Connor Raymond Stewart */
/*Student Number: 101041125 */

#include <iostream>
#include <string>
#include "UI.h"
#include "input.h"
using namespace std;

//the main program is the entry point for the program
int main() {
	bool RUN_PROGRAM = true;
	input start(RUN_PROGRAM); //initilize user prompt
	start.run(); //gets user input
}//END main