/*Name: Connor Raymond Stewart */
/*Student Number: 101041125 */

#include <iostream>
#include <string>
using namespace std;
const int FIFTH_WORD = 4;
const int FOURTH_WORD = 3;
const int THIRD_WORD = 2;
const int SECOND_WORD = 1;
const int FIRST_WORD = 0;

class parser {
	private:
	string* userArray;
	int returnValue;
	public:
	parser(string *array);
	int command();
	
};