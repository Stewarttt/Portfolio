/*Name: Connor Raymond Stewart */
/*Student Number: 101041125 */

#include <iostream>
#include <string>
#include "UI.h"
#include "input.h"
#include "parser.h"
using namespace std;

parser::parser(string *array){ //constructor, copys pointer to array
	userArray = array;
	returnValue = -1;
	
}
int parser::command() { //breaks down user input into actual commands

	
	
	//returns a number corrosponding to requested output message
	if (userArray[FIRST_WORD] == ".help") {
		returnValue = 1; 
	}
	else if (userArray[FIRST_WORD] == ".exit") {
		returnValue = 5;
	}
	else if (userArray[FIRST_WORD] == ".read") {
		returnValue = 26;
	}
	else if (userArray[FIRST_WORD] == ".comment") {
		returnValue = 29;
	}
	else if (userArray[FIRST_WORD] == ".logging") {
		if (userArray[SECOND_WORD]  == "-c") {
			returnValue = 27;
		}
		else if (userArray[SECOND_WORD]  == "-b") {
			returnValue = 28;
		}
		else {
			returnValue = -2; //negitive signifies error codes
		}//END IF
	}
	else if (userArray[FIRST_WORD] == "add") {
		if (userArray[THIRD_WORD] == "") {
			returnValue = -5;
		}
		if (userArray[SECOND_WORD] == "-s") { //song
			returnValue = 6;
		}
		else if (userArray[SECOND_WORD] == "-u") { //user
			returnValue = 7;
		}
		else if (userArray[SECOND_WORD] == "-p") { //playlist
			returnValue = 8;
		}
		else if (userArray[SECOND_WORD] == "-r") { //recording
			returnValue = 9;
		}
		else if (userArray[SECOND_WORD] == "-t") { //tracks
			if (userArray[THIRD_WORD] != "") {
				if (userArray[FOURTH_WORD] != "") {
					returnValue = 22;
				}
				else {
					returnValue = -4;
				}//END IF
			}
			else { //number of augments
				returnValue = -3;
			}//END IF
		}
		else if (userArray[SECOND_WORD] == "-pt") { //playlist tracks
			if (userArray[THIRD_WORD] != "") {
				if (userArray[FOURTH_WORD] != "") {
					returnValue = 23;
				}//END IF
				else {
					returnValue = -4;
				}//END IF
			}
			else { //number of augments
				returnValue = -3;
			}//END IF
		}
		else if (userArray[SECOND_WORD] == "-up") { //user playlists
			if (userArray[THIRD_WORD] != "") {
				if (userArray[FOURTH_WORD] != "") {
					returnValue = 24;
				}
				else {
					returnValue = -4;
				}//END IF
			}
			else { //number of augments
				returnValue = -3;
			}//END IF
		}//END IF
		else {
			returnValue = -2;
		}
		
	}
	else if (userArray[FIRST_WORD] == "delete") {
		if (userArray[SECOND_WORD] == "-s") { 
			returnValue = 10;
		}
		else if (userArray[SECOND_WORD] == "-sp") { 
			returnValue = 25;
		}
		else if (userArray[SECOND_WORD] == "-u") {
			returnValue = 11;
		}
		else if (userArray[SECOND_WORD] == "-p") {
			returnValue = 12;
		}
		else if (userArray[SECOND_WORD] == "-r") {
			returnValue = 13;
		}
		else if (userArray[SECOND_WORD] == "-t") {
			returnValue = 31;
		}
		else if (userArray[SECOND_WORD] == "-up") {
			returnValue = 32;
		}
		else {
			returnValue = -2;
		}//END IF
	}
	else if (userArray[FIRST_WORD] == "display") {
		if (userArray[SECOND_WORD] == "-s") {
			returnValue = 14;
		}
		else if (userArray[SECOND_WORD] == "-u") {
			returnValue = 15;
		}
		else if (userArray[SECOND_WORD] == "-p") {
			returnValue = 16;
		}
		else if (userArray[SECOND_WORD] == "-r") {
			returnValue = 17;
		}
		else if (userArray[SECOND_WORD] == "-up") { //user playlist
			if (userArray[THIRD_WORD] != "") {
				returnValue = 18;
			}
			else { //number of augments
				returnValue = -3;
			}//END IF
			
		}
		else if (userArray[SECOND_WORD] == "-ups") { //users playlists songs
			if (userArray[THIRD_WORD] != "") {
				if (userArray[FOURTH_WORD] != "") {
					returnValue = 19;
				}
				else {
					returnValue = -4;
				}//END IF
			}
			else { //number of augments
				returnValue = -3;
			}//END IF
		}
		else if (userArray[SECOND_WORD] == "-t") {
			returnValue = 20;
		}
		else if (userArray[SECOND_WORD] == "-pt") {
			returnValue = 21;
		}
		else {
			returnValue = -2;
		}//END IF
	}
	else {
		returnValue = -1;
	}//END IF
	return returnValue;
}//END command
