/*Name: Connor Raymond Stewart */
/*Student Number: 101041125 */

#include <iostream>
#include <string>
#include "UI.h"
#include "input.h"
#include "logging.h"
using namespace std;

UI::UI(int value){
	val = value;
	state = 0;
}//END UI
void UI::setVal(int value) {
	val = value;
	state = 0;
}//END setVal
		
string UI::interface() {

	
	//gets an output value based of initilized val from parser class
	//error messages
	if (val == -1) {
		output = "Please enter a command: \n";
	}
	else if (val == -2) {
		output = "invalid entry near augment 2\n";
	}
	else if (val == -3) {
		output = "Need entry at augment 3\n";
	}
	else if (val == -4) {
		output = "Need entry at augment 4\n";
	}
	else if (val == -5) {
		output = "Missing augment 3\n";
	}
	
	//prompt messages
	if (val == 0) { //input prompt
		output = "ENTER: ";
	}
	else if (val == 1) { //help
		output = "++++++++++++++++++++++++++++++HELP++++++++++++++++++++++++++++++\n \
COMMANDS:\n\
add //add data to collections\n\
	add -r id title artist producer year //add recordings\n\
	add -s sid title composer //add song\n\
	add -t albumID songID track_number //add track\n\
	add -u user_id name //add users\n\
	add -p user_id, playlist_name //add playlists\n\
	add -pt user_id playlist_name song_id //add playlist tracks\n\
	add -up user_id playlist_name //associate a user with a playlist\n\n\
delete //add data to collections\n\
	delete -s song_id //delete song\n\
	delete -sp song_id playlist_name user_name //delete song from playlist\n\
	delete -r recording_id //delete recording\n\
	delete -u user_id //delete user\n\
	delete -up user_id playlist_name //delete user playlist\n\
	delete -t song_id recording_id //delete track\n\n\
show //show entries in collections\n\
	display -s //displays all songs\n\
	display -u //displays all users\n\
	display -r //displays all recordings\n\
	display -t //displays all tracks\n\
	display -up user_id playlist_name //displays a users playlists\n\
	display -ups user_id playlist_name //displays a users playlists songs\n\
	display -pt //displays all playlist tracks\n\n\
SHELL_ONLY_COMMANDS:\n\
	.quit   //quit the application\n\
	.read //read a script file, prompt for filename will follow\n\
	.logging -c //starts logging of all entered commands\n\
	.logging -b //starts logging of all entered commands and program output\n\
	.help //shows this help menue\n\
\n++++++++++++++++++++++++++++++HELP++++++++++++++++++++++++++++++\n";
	}
	else if (val == 2) { //command message
		output = "Output is now being logged\n";
	}
	else if (val == 3) { //command message
		output = "Input is now being logged\n";
	}
	else if (val == 4) { //command message
		output = "Both input and output are now being logged\n";
	}
	else if (val == 5) { //exit message
		output = "Program will now exit\n";
		exit(0);
	}
	else if (val == 6) { //output input
		output = "program will now add a song:\n";
	}
	else if (val == 7) { //output input
		output = "program will now add a user:\n";
	}
	else if (val == 8) { //output input
		output = "program will now add a playlist:\n";
	}
	else if (val == 9) { //output input
		output = "program will now add a recording:\n";
	}
	else if (val == 10) { //output input
		output = "program will now remove a song from all playlists:\n";
	}
	else if (val == 11) { //output input
		output = "program will now remove a user:\n";
	}
	else if (val == 12) { //output input
		output = "program will now remove a playlist:\n";
	}
	else if (val == 13) { //output input
		output = "program will now remove a recording:\n";
	}
	else if (val == 14) { //output input
		output = "program will now serch all songs:\n";
	}
	else if (val == 15) { //output input
		output = "program will now serch all users:\n";
	}
	else if (val == 16) { //output input
		output = "program will now serch all playlists:\n";
	}
	else if (val == 17) { //output input
		output = "program will now serch all recordings:\n";
	}
	else if (val == 18) { //output input
		output = "program will now serch what playlists this user owns:\n";
	}
	else if (val == 19) { //output input
		output = "program will now serch what songs are within this users playlist:\n";
	}
	else if (val == 20) { //output input
		output = "program will now serch all tracks:\n";
	}
	else if (val == 21) { //output input
		output = "program will now serch all playlist tracks:\n";
	}
	else if (val == 22) { //output input
		output = "recording is now added to song via. the associated tracks:\n";
	}
	else if (val == 23) { //output input
		output = "song is now added to playlist via. the associated playlist track:\n";
	}
	else if (val == 24) { //output input
		output = "user now has playlist added:\n";
	}
	else if (val == 25) {
		output = "Song will be deleted from the playlist specified:\n";
	}
	else if (val == 26) {
		output = "Please enter a file name:\n";
	}
	else if (val == 27) {
		output = ":::LOGGING:::\n";
	}
	else if (val == 28) {
		output = ":::LOGGING:::\n";
		state = !state;
	}
	else if (val == 31) {
		output = "program will now delete specified track\n";
		state = !state;
	}
	else if (val == 32) {
		output = "program will now delete specified user playlist\n";
		state = !state;
	}

	
	return output; //return output message 
	
		
	
}//END interface
