/*Name: Connor Raymond Stewart */
/*Student Number: 101041125 */

#include <iostream>
#include <string>
using namespace std;

class UI {
	private:
	int val;
	int state;
	string output;
	public:
	UI(int value);
	string interface();
	void setVal(int value);
};