/*Name: Connor Raymond Stewart */
/*Student Number: 101041125 */

#include <iostream>
#include <string>
#include <fstream>

using namespace std;
const int MAX_FILE_LENGTH = 100;
const int LOG_INPUT = 1;
const int LOG_INPUT_AND_OUTPUT = 2;
const int LOG_OFF = 0;
class reader {
	private:
	string fileName;
	public:
	reader(string fileName);
	void getFileArray();
	
};