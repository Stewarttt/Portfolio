/*Name: Connor Raymond Stewart */
/*Student Number: 101041125 */

#include <iostream>
#include <string>
#include <string.h>
#include "reader.h"
#include "UI.h"
#include "parser.h"
#include <fstream>
#include <locale>
#include "logging.h"

using namespace std;


reader::reader(string name){
	fileName = name;
} //END reader
void reader::getFileArray() {
	
	//opens file by designated name
	ifstream input(fileName);	
	
	
	
	if(input.is_open()) {
        string fileArray[MAX_FILE_LENGTH];
		int iterations = 0;
		int toUI;
		string str;
		int LOG_COMMANDS = 27;
		int LOG_BOTH = 28;
		int COMMENT = 29;
		int FIRST_CHAR = 0;
		int word = 0;
		int length;
		locale loc;
		logging addLine("__PLACEHOLDER__");

		while (getline(input, str)) { //for the amount of lines within the input file
			str += " ";		
			addLine.setWrite(str); //initilize
			addLine.writeToFile(); //split line by spaces
			int size = str.size(); //get size of string
			for(int i = 0; i<size; ++i) { //run for the number of words per line
				if (str[i] == ' ') { //split by space
					  word += 1;
				}
				else {
					str[i] = tolower(str[i], loc); //add word to array in lowercase
					fileArray[word] += str[i]; //add word to array index
				}//END IF
			}  
			
			iterations = word;
			word = 0;
			
			parser thisCommand(fileArray); //parse input
			toUI = thisCommand.command(); //find output repley
			UI current(toUI); //initilize with UI value
			current.setVal(toUI); //get UI to prompt based on output value
			cout << current.interface(); //print the prompt
			
			
			if (toUI == LOG_COMMANDS) {//log just input
				if (addLine.getState() == LOG_OFF) { //if logging is off
					addLine.swapState(LOG_INPUT); //turn input logging on
				}
				else { //if logging is on turn it off
					addLine.swapState(LOG_OFF);
				}//END IF
			}
			else if (toUI == LOG_BOTH) { //log both
				if (addLine.getState() == LOG_OFF) { //if logging is off
					addLine.swapState(LOG_INPUT_AND_OUTPUT); //turn input/output logging on
				}
				else { //if logging is on turn it off
					addLine.swapState(LOG_OFF);
				}//END IF
			}//END IF
			
		
			
			if (addLine.getState() == LOG_INPUT_AND_OUTPUT) { //log output
				addLine.setWrite(current.interface());
				addLine.writeToFile(); //write output to file
			}
			
			if (toUI != COMMENT)	{
				for (int i =0; i<=iterations; ++i) {
					cout << fileArray[i] << endl;
					if (addLine.getState() == LOG_INPUT_AND_OUTPUT) {
						addLine.setWrite(fileArray[i]);
						addLine.writeToFile();
					} //END IF
				}
			}
			else {
				fileArray[FIRST_CHAR] = "////";
				for (int i =0; i<=iterations; ++i) {
					cout << fileArray[i] << " ";
					if (addLine.getState() == LOG_INPUT_AND_OUTPUT) {
						addLine.setWrite(fileArray[i]);
						addLine.writeToFile();
					}//END IF
				}//END FOR
			}//END IF
			cout << "\n";
			
			
			length = sizeof(fileArray)/sizeof(fileArray[FIRST_CHAR]);
			for (int i = 0; i< length; ++i) {
				fileArray[i] = "";
			}
			

			++iterations;
        }//END WHILE

    }//END IF
	
	
}// END getFileArray
