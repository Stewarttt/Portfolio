/*
(c) 2018 LD Nel
To test:
Open two browsers at http://localhost:3000/canvasWithTimer.html

//collaboration through polling
//=============================

When the blue cube is moved with the arrow keys, a POST message will be
sent to the server when the arrow key is released, also while the key is
held down.

Clients also request the position of the movingBox by polling the server.
The smoothness is thus affected by the rate at which the polling timer
runs. The trade off is smooth behaviour vs. network traffic.

This polling app is a great candidate to use web sockets instead of polling.

Only the client moving the box will drop waypoints, the other clients don't
see the local waypoints, just their own.
*/

//Cntl+C to stop server

const app = require('http').createServer(handler)
const io = require('socket.io')(app) //wrap server app in socket io capability
const fs = require("fs") //need to read static files
const url = require("url") //to parse url strings

players = [];
let counter = 0;

const PORT = process.env.PORT || 3000
app.listen(PORT) //start server listening on PORT

//server maintained location of moving box
let movingBoxLocation = {
  x: 100,
  y: 100
} //will be over-written by clients

const ROOT_DIR = "html" //dir to serve static files from

const MIME_TYPES = {
  css: "text/css",
  gif: "image/gif",
  htm: "text/html",
  html: "text/html",
  ico: "image/x-icon",
  jpeg: "image/jpeg",
  jpg: "image/jpeg",
  js: "application/javascript",
  json: "application/json",
  png: "image/png",
  svg: "image/svg+xml",
  txt: "text/plain"
}

function get_mime(filename) {
  for (let ext in MIME_TYPES) {
    if (filename.indexOf(ext, filename.length - ext.length) !== -1) {
      return MIME_TYPES[ext]
    }
  }
  return MIME_TYPES["txt"]
}
let player = 0 //number of players connected to server
let playerNum = 0; //the current player
let playerOne = false; //player one is playing
let playerTwo = false; //player two is playing
io.on('connection', function(socket){ //socket sychronized data between clients	
	player = Object.keys(io.sockets.connected).length
	console.log("Player " + player + " has joined!");
	
    socket.on('puckPosition', function(data){ //contains data about puck position
		//to broadcast message to everyone including sender:
		io.emit('puckPosition', data) //broadcast to everyone including sender
    })
	
	socket.on('setPlayerInstance', function(data) { //give each client a unique ID number
		io.emit('setPlayerInstance', playerNum); //tell client a unique number that no other client has
		playerNum++ //increment this value
	})
	
    socket.on('playerNumber', function(data) { //sets current spectator to player, if possible
		if (data[1] == 1) {
			playerOne = false;
			io.emit('playerNumber', [2, data[0]]); //the array represents the new role, and who requested the change
		}
		else if (data[1] == 2) {
			playerTwo = false;
			io.emit('playerNumber', [3, data[0]]); //the array represents the new role, and who requested the change
		}
		else {		
			if (playerOne == false) { //set to player one
				playerOne = true; //prevents role duplication			
				io.emit('playerNumber', [1, data[0]]); //the array represents the new role, and who requested the change
			}
			else if (playerTwo == false) { //set to player two
				playerTwo = true; //set to player one
				io.emit('playerNumber', [2, data[0]]); //the array represents the new role, and who requested the change
			}
			else { //set to spectator
				io.emit('playerNumber', [3, data[0]]); //the array represents the new role, and who requested the change
			}
		}
    })
	
	socket.on('release', function(data) { //sets current player to spectator
		if (data == 1) {
			playerOne = false; //set role to open
			io.emit('release', 1) //send blank data back to client
		} 
		else if (data == 2) {
			playerTwo = false; //set role to open
			io.emit('release', 1) //send blank data back to client
		}
		io.emit('release', 1) //send blank data back to client
	})
	
	socket.on('reloadPlayers', function(data) { //resets all players roles
		playerOne = playerTwo = false; //reset all roles
		io.emit('release', 1) //send blank data back to client
	});
})


function handler(request, response)  {
    let urlObj = url.parse(request.url, true, false)
    console.log("\n============================")
    console.log("PATHNAME: " + urlObj.pathname)
    console.log("REQUEST: " + ROOT_DIR + urlObj.pathname)
    console.log("METHOD: " + request.method)

    let receivedData = ""

    //attached event handlers to collect the message data
    request.on("data", function(chunk) {
      receivedData += chunk
    })

    //event handler for the end of the message
    request.on("end", function() {
      console.log("REQUEST END: ")
      console.log("received data: ", receivedData)
      console.log("type: ", typeof receivedData)

      if (request.method == "GET") {
        //handle GET requests as static file requests
        fs.readFile(ROOT_DIR + urlObj.pathname, function(err, data) {
          if (err) {
            //report error to console
            console.log("ERROR: " + JSON.stringify(err))
            //respond with not found 404 to client
            response.writeHead(404)
            response.end(JSON.stringify(err))
            return
          }
          response.writeHead(200, {
            "Content-Type": get_mime(urlObj.pathname)
          })
          response.end(data)
        })
      }
    })
  }

console.log("Server Running at PORT: 3000  CNTL-C to quit")
console.log("To Test:")
console.log("Open several browsers at: http://localhost:3000/assignment3.html")
