/*
(c) 2018 LD Nel

Javasript to handle mouse dragging and release
to drag a string around the html canvas
Keyboard arrow keys are used to move a moving box around
(The mouse co-ordinates are wrong if the canvas is scrolled with scroll bars.
 Exercise: can you fix this?)

Here we are doing all the work with javascript and jQuery. (none of the words
are HTML, or DOM, elements. The only DOM element is just the canvas on which
where are drawing.

This example shows examples of using JQuery
JQuery syntax:
$(selector).action();
e.g.
$(this).hide() - hides the current element.
$("p").hide() - hides all <p> elements.
$(".test").hide() - hides all elements with class="test".
$("#test").hide() - hides the element with id="test".

Mouse event handlers are being added and removed using jQuery and
a jQuery event object is being passed to the handlers

Keyboard keyDown handler is being used to move a "moving box" around

Notice in the .html source file there are no pre-attached handlers.
*/

//Use javascript array of objects to represent pucks and their locations
words = []
words.push({ word: "1", x: 535+100, y: 460, velX: 0, velY: 0 })
words.push({ word: "2", x: 555+100, y: 460, velX: 0, velY: 0 })
words.push({ word: "3", x: 575+100, y: 460, velX: 0, velY: 0 })
words.push({ word: "4", x: 595+100, y: 460, velX: 0, velY: 0 })
words.push({ word: "5", x: 615+100, y: 460, velX: 0, velY: 0 })
words.push({ word: "6", x: 635+100, y: 460, velX: 0, velY: 0 })

let userInformation = 
"(1) Left mouse button moves a puck via dragging<hr>" + 
"(2) Right mouse button allows you to sling a puck by pulling back and letting go of the button (think angry birds)" + 
"-You must hold the puck with the right mouse, pull the mouse back, then let go of the right mouse button <hr>" + 
"(3) The become player button will promote a spectator to a player only if there is room for another player <hr>" + 
"(4) the reset players button resets the players, allowing a spectator to become a player again" +
"-It sets everyone to spectator; If become player dosnt work, just click reset players <hr>" + 
"(5) to start a new game, disconnect all clients and reconnect the browser using the server link <hr>";



speeds = [[]]; //contains the change in speeds of the moving rocks

let hadRightDown = false; //checks if the right mouse button was used
let currentSling = -1; //contains the value of the last rock slung

let timer //used to control the free moving word

let instanceID = null;
let deltaX, deltaY //location where mouse is pressed
let name = -1; //indicates the name of the players role (player one, player two, or spectator)
let canvas = document.getElementById("canvas1") //our drawing canvas
let motion = false; //if the puck is in motion
let changeRightDown = false; //if the right mouse button value should be changed
let nothing = false; //if nothing has changed
const fontPointSize = 18 //point size for word text
const wordHeight = 20 //estimated height of a string in the editor
const editorFont = "Arial" //font for your editor

//connect to server and retain the socket
let socket = io('http://' + window.document.location.host)


socket.on('setPlayerInstance', function(data) {	//give client a unique id
	if (instanceID == null) { //run only if no id value is set yet
		instanceID = data; //set id value
	}
})
socket.on('playerNumber', function(data) { //set players role for game
	if (data[1] == instanceID) { //verify that the id of the client and the id of the information match
		name = data[0]; //set the players role
	}
})
socket.on('release', function(data) { //release player role, change to spectator
	name = -1; //set role to spectator
})
socket.on('reloadPlayers', function(data) { //set everyone to spectator
	name = -1; //set role to spectator
})

socket.on('puckPosition', function(data) { //deliver the puck positions to all players
  let locationData = JSON.parse(data); //put the puck data into a JSON
  drawCanvas();
  words = locationData; //set new puck positions
})

//socket.emit("playerNumber", instanceID); //get a unique ID number

function notifyStatus () { //fill HTML text at bottom of page with information
	//add the formated text as an HTML footer on the page, below the request label bar
	let textDiv = document.getElementById("text-area")
	if (name == 1) { //prompt player their player one
		textDiv.innerHTML = `<p>${"You are: Player One (Green)" + "<hr>" + userInformation}</p>`;
	}
	else if (name == 2) { //prompt player their player two
		textDiv.innerHTML = `<p>${"You are: Player Two (Orange)" + "<hr>" + userInformation}</p>`;
	}
	else { //prompt player their spectator
		textDiv.innerHTML = `<p>${"You are: Spectator" + "<hr>" + userInformation}</p>`;
	}
}
function becomePlayer() { //request server to become player
	socket.emit('playerNumber', [instanceID, name]); //ask server if theres a place for a new player
	notifyStatus(); //update information to user
}
function releaseControl() { //request server to become spectator
	socket.emit('release', name); //tell server client is no longer player
	notifyStatus(); //update user information
}
function reset() { //request server to set everyone to spectator
	socket.emit('reloadPlayers', 1); //set all players to spectator
	notifyStatus(); //update user information
}
function getWordAtLocation(aCanvasX, aCanvasY) {
  //locate the puck targeted by aCanvasX, aCanvasY
  const context = canvas.getContext("2d");
  
  //check all pucks
  for (let i = 0; i < words.length; i++) {
	  //check if mouse is pressing puck
    if (Math.sqrt((aCanvasX-words[i].x)*(aCanvasX-words[i].x) + (aCanvasY-words[i].y)*(aCanvasY-words[i].y)) < 15) {
      return i //return the puck found
    }
  }
}

function setupBoard(context) { //print the board 
	//create a line separating two halves of the canvas
	context.fillStyle = "black";
	context.fillRect(500+100, 0, 20, 500+100); //left wall
	context.fillRect(650+100, 0, 20, 500+100); //right wall
	context.fillRect(500+100, 475, 150, 500+100); //bottom wall
	context.fillRect(500+100, 0, 150, 20); //top wall
	context.fillStyle = "blue"; //change print colour
	
	//create a Circle
	context.beginPath();
	context.arc(250,250,215,0,2*Math.PI); //large left circle, outer ring
	context.lineWidth = 50;
	context.stroke();
	
	//create a Circle
	context.beginPath();
	context.arc(585+100,95,45,0,2*Math.PI); //mini circle, outer ring
	context.lineWidth = 10;
	context.stroke();
	
	context.strokeStyle = "red";
	//create a Circle
	context.beginPath();
	context.arc(585+100,95,20,0,2*Math.PI); //large circle, inner ring
	context.lineWidth = 10;
	context.stroke();
	
	context.fillStyle = "red";
	//create a Circle
	context.beginPath();
	//inside math represents the formula for a scale model of the large circles inner ring
	context.arc(250,250,(20/45)*200,0,2*Math.PI); //small circle, inner ring
	context.lineWidth = 50;
	context.stroke();
	
	context.strokeStyle = "blue"; //set colour back to blue
}

function interceptTest(circleOne,circleTwo) { //checks if the pucks intersect with each other
	//check the position of the pucks minus their future position based off velocities
	let xTwo = circleTwo.x - circleTwo.velX*0.1;
	let yTwo = circleTwo.y - circleTwo.velY*0.1;
	let xOne = circleOne.x - circleOne.velX*0.1;
	let yOne = circleOne.y - circleOne.velY*0.1;
	//calculate this distance between the pucks
	let distance = Math.sqrt((((xTwo - xOne)*(xTwo - xOne)) + ((yTwo - yOne)*(yTwo - yOne))));
    let radius = 15;
	return distance < radius; //if puck distance is smaller then radius then their a collision
}

function collitionCalculator(index,i) { //calculates the result of a puck collision
	if (words[index].velX == 0 && words[index].velY == 0) {
		return; //check if the pucks are moving
	}
	if (currentSling != -1) { //check if somthing is being slinged
		return; 
	}	
	
	//the two adjacent pucks
	let circleOne = words[index]
	let circleTwo = words[i]
	
	//the coordinents of the adjacent pucks
	let xOne = circleOne.x - circleOne.velX*0.2;
	let yOne = circleOne.y - circleOne.velY*0.2;
	let xTwo = circleTwo.x - circleTwo.velX*0.2;
	let yTwo = circleTwo.y - circleTwo.velY*0.2;
	//the velocity of the inelastic pair
	let movingVelocity = Math.sqrt(circleOne.velX*circleOne.velX + circleOne.velY*circleOne.velY)

	//the hypotinuse of the collition vector
	let hypotinuse = Math.asin((yTwo-yOne)/30)
	//the tejectory of the colliding (alpha) puck
	let trejectory = Math.asin(circleOne.velX / movingVelocity)
	//the angle of collision between the perpendicular vector between the two pucks
	let angle = Math.PI/2 - hypotinuse - trejectory;
	//the angle adjacent to the derived angle
	let derivedAngle = hypotinuse - angle;
	
	
	//the velocity vector of both pucks
	let velocityOne = movingVelocity*Math.sin(angle);
	let velocityTwo = movingVelocity*Math.cos(angle);
	
	//convert velocities into x and y velocities
	words[index].velX = velocityOne*Math.cos(derivedAngle);
	words[index].velY = velocityOne*Math.sin(derivedAngle);
	
	words[i].velX = velocityTwo*Math.cos(hypotinuse);
	words[i].velY = velocityTwo*Math.sin(hypotinuse);		
}

function setupPucks(context, data, index) {	//draws puck objects
	let circleRadius = 15;
	let leftBound = 520+100;
	let rightBound = 630+100;
	let upperBound = 20;
	let lowerBound = 475;
	let middleBound = 250;
	let lowerVisibleY = 145+5;
	let upperVisibleY = 45-5;
	let ratio = 105/500; //ratio of big target to little target

	//create a Circle
	context.beginPath();
	context.arc(data.x,data.y,1,0,2*Math.PI);
	context.lineWidth = circleRadius;
	context.stroke();
	
	
	//sets up borders around enclosed curling rink 
	//pucks will bounce off the wall if they hit the wall
	//left wall
	if (data.x < leftBound+10) {
		//data.word = "b";
		data.x = leftBound+10;
		data.velX = -data.velX*0.8;
		data.velY = data.velY*0.75;
	}
	if (data.x > rightBound+15) { //right wall
		//data.word = "b";
		data.x = rightBound+10;
		data.velX = -data.velX*0.8;
		data.velY = data.velY*0.75;
	}
	if (data.y < upperBound+10) { //top wall
		//data.word = "b";
		data.y = upperBound+10;
		data.velX = data.velX*0.75;
		data.velY = -data.velY*0.8;
	}
	if (data.y > lowerBound-10) { //bottom wall
		data.y = lowerBound-10;
		data.velX = data.velX*0.75;
		data.velY = -data.velY*0.8;
	}
	
	if (data.x+15 > leftBound && data.x-15 < rightBound) { //if the pucks within bounds
		if (data.y-15 < lowerVisibleY && data.y+15 > upperVisibleY) { //if the pucks within bounds
			//create a Circle		
			context.beginPath();
			context.arc((data.x-620)/ratio-60,(data.y-upperVisibleY)/ratio-10,1,0,2*Math.PI);
			context.lineWidth = circleRadius/ratio;
			context.stroke();
		}
	}	
}

function drawCanvas() {
	canvas.width = 800; //increase canvas size
	canvas.height = 500;
	let changeColour = 2; //tells machine which pucks to change colours for
	
	notifyStatus(); //update the HTML footer information
	
	if (instanceID == null) { //if the instance is not set yet
		socket.emit("setPlayerInstance", 1); //set instance
	}
	
	//gets the canvas id
    const context = canvas.getContext("2d");
	//settigns for drawing things on the canvas
    context.fillStyle = "white";
    context.fillRect(0, 0, canvas.width, canvas.height); //erase canvas
    context.font = "" + fontPointSize + "pt " + editorFont;
    context.fillStyle = "cornflowerblue";
    context.strokeStyle = "blue"; 
    
	setupBoard(context); //sets up the board
	
	context.strokeStyle = "green"; //sets the colour of the circles to green
	for (let i = 0; i < words.length; i++) { //for all pucks
		setupPucks(context, words[i], i); //draw the pucks
		if (i == changeColour) { //sets the last three pucks to this colour
			context.strokeStyle = "orange"; //change puck colour to orange
		}
	}
	
}

function handleMouseDown(e) {	
	//get mouse location relative to canvas top left
	let rect = canvas.getBoundingClientRect()
	let canvasX = e.pageX - rect.left //use  event object pageX and pageY
	let canvasY = e.pageY - rect.top
	wordBeingMoved = getWordAtLocation(canvasX, canvasY)
	let puckID;
	
	//sets the id of the puck being clicked
	try {
		puckID = words[wordBeingMoved].word;
	} 
	catch (exception) {
		puckID -1;
	}
	
	//checks if this movement is valid
	if (((puckID == "1" || puckID == "2" || puckID == "3") && (name == 1)) || 
		((puckID == "4" || puckID == "5" || puckID == "6") && (name == 2))) {		
	
		if (e.which == 3 && wordBeingMoved != null) { //if the right mouse button is pressed
			currentSling = wordBeingMoved; //set the index of the rock about to be slinged
			$("#canvas1").mousemove(handleRightMove);
			$("#canvas1").mouseup(handleMouseUp);
		}
		else {	//if any other mouse button is pressed
			if (wordBeingMoved != null) {
				//find the change in position of the puck
				deltaX = words[wordBeingMoved].x - canvasX
				deltaY = words[wordBeingMoved].y - canvasY
				//set the velocity to zero
				words[wordBeingMoved].velX = 0;
				words[wordBeingMoved].velY = 0;
				
				//attache mouse move and mouse up handlers
				$("#canvas1").mousemove(handleMouseMove)
				$("#canvas1").mouseup(handleMouseUp)
			}
			// Stop propagation of the event and stop any default
			//  browser action
			e.stopPropagation()
			e.preventDefault()
			drawCanvas()
		} 
	}
		
}

function handleRightMove(e) {
	//get mouse location relative to canvas top left
	let rect = canvas.getBoundingClientRect()
	
	let canvasX = e.pageX - rect.left //use  event object pageX and pageY
	let canvasY = e.pageY - rect.top
	
	//if the rock is being slinged and it isnt deactivated
	if (currentSling != null && words[currentSling].word != "i") {
	//find the change in velocity after sling
	let deltaX = words[currentSling].x - canvasX
	let deltaY = words[currentSling].y - canvasY
	
	let velocityX = -deltaX; //inverted velocity
	let velocityY = -deltaY;
	
	if (velocityX > 50) { 
		velocityX = 50; //max velocity
	}
	if (velocityY > 50) { 
		velocitY = 50; //max velocity
	}
	//set the new velocity values
	words[currentSling].velX = velocityX;
	words[currentSling].velY =velocityY;	
	hadRightDown = true; //says the right mouse button was the last button pressed
	}
	
}

function handleMouseMove(e) {	
    console.log("mouse move");
    lastMoved = wordBeingMoved;

    //get mouse location relative to canvas top left
    let rect = canvas.getBoundingClientRect()
    let canvasX = e.pageX - rect.left
    let canvasY = e.pageY - rect.top
  
    try {
		//if a puck is not deactivated
		if (words[wordBeingMoved].word != "i") {
			//set the new position of the puck after moving
			words[wordBeingMoved].x = canvasX + deltaX
			words[wordBeingMoved].y = canvasY + deltaY
		}
	} catch (exception) {}
  
    e.stopPropagation()  
    drawCanvas() //reset canvas
	//update puck position on all clients
    let jsonString = JSON.stringify(words)
	socket.emit('puckPosition', jsonString) 
}

function handleMouseUp(e) {
  console.log("mouse up")
  e.stopPropagation()

  //remove mouse move and mouse up handlers but leave mouse down handler
  $("#canvas1").off("mousemove", handleMouseMove); //remove mouse move handler
  $("#canvas1").off("mousemove", handleRightMove); //remove mouse up handler
  $("#canvas1").off("mouseup", handleMouseUp); //remove mouse up handler
  currentSling = -1 //reset this value for the next run
	
  drawCanvas() //redraw the canvas
}

function movement(index) {
	if (index == -1) {
		return; //value isnt initialized
	}
	
	//gather information from the arrays
	let previousX = words[index].x;
	let previousY = words[index].y;
	let velocityX = 0;
	let velocityY = 0;
	let length = speeds.length;

	//calcualte the new velocity
	for (let i = 0; i < length; i++) {
		velocityX += speeds[i][0];
		velocityY += speeds[i][1];		
	}
	//divide the velocity by the number of rocks being calculated
	words[index].velX = velocityX/length; 
	words[index].velY = velocityY/length;
}

//JQuery Ready function -called when HTML has been parsed and DOM
//created
//can also be just $(function(){...});
//much JQuery code will go in here because the DOM will have been loaded by the time
//this runs
function handleTimer() {
	let friction = 0.98;
	let pixelToMeters = 0.1;
	//changeRightDown = false; 
	//check if no rocks are moving within the array of all rocks
	for (let i = 0; i < words.length; i++) {
		if (Math.abs(words[i].velY) > 1) {
			//states that the rightDown boolean it to be changed to false
			changeRightDown = true; 
		}
	}
	
	for (let i = 0; i < words.length; i++) {
		if (currentSling == i) {
			continue; //we cant calculate on a rock about to be shot
		}		
		 //add change in velocity due to fiction
		words[i].x -= words[i].velX*pixelToMeters;
		words[i].velX *= friction;
		words[i].y -= words[i].velY*pixelToMeters;
		words[i].velY *= friction;
		
		if (Math.abs(words[i].velX) < 0.5) { //stop rocks at very low velocities
			words[i].velX = 0;
		}
		if (Math.abs(words[i].velY) < 0.5) { //stop rocks at very low velocities
			words[i].velY = 0;
			//if there was a no moving rocks and the last button pressed was the right button
			if (!changeRightDown && hadRightDown) {
				hadRightDown = false;
			}				
		}
		else {
			//if the right mouse button was the last button pressed
			if (hadRightDown == true) {
				//pick a alpha rock for comparison
				for (let k = 0; k < words.length; k++) {	
					//all rocks relative to alpha rock
					for (let i = 0; i < words.length; i++) {	
						//check if two unique pucks collide
						if (k != i && interceptTest(words[k], words[i])) {
							collitionCalculator(k, i); //calculate collition
						}
					}
				}
			}
			nothing = true; //say nothings changed
		}		
	}
	if (nothing) { //runs if no velocities have changed
		nothing = false; //resets the boolean value
		let jsonString = JSON.stringify(words) //sends the new puck positions to the other clients via socket
		socket.emit('puckPosition', jsonString) 
	}
  drawCanvas()
}

//KEY CODES
//should clean up these hard coded key codes
const RIGHT_ARROW = 39
const LEFT_ARROW = 37
const UP_ARROW = 38
const DOWN_ARROW = 40

function handleKeyDown(e) {
  //create a JSON string representation of the data object
  let jsonString = JSON.stringify(dataObj)

  //update the server with a new location of the moving box
  socket.emit('puckPosition', jsonString)
}

function handleKeyUp(e) {
  console.log("key UP: " + e.which)
  //create a JSON string representation of the data object
  let jsonString = JSON.stringify(dataObj)
  socket.emit('puckPosition', jsonString) 
}

$(document).ready(function() {
  //add mouse down listener to our canvas object
  $("#canvas1").mousedown(handleMouseDown)
  //add keyboard handler to document
  timer = setInterval(handleTimer, 0.0005) //reload server as fast as possible
  drawCanvas()
})
