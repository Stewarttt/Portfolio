Name: Connor Stewart
Student Number: 101041125
Email Address: connorrstewart@cmail.carleton.ca

Node.js Version: 8.11.4
OS Tested: Windows 10 & Linux (xubuntu)
Needed Code:
	Node: go to https://nodejs.org/dist/ and download v8.11.4 for your operating system
	Npm: to install npm -v 6.4.1:
		go into the CMD/terminal and type: npm install npm@latest -g
			Alternativly (if npm latest has changed): npm install -g npm@6.4.1
	Socket.oi: Open the CMD/terminal to the same directory as the server.ks code and execute
		npm install socket.io
		

Launch: node server.js
Testing:
	Visit: http://localhost:3000/assignment3.html
	(1) Left mouse button moves a puck via dragging
	(2) Right mouse button allows you to sling a puck by pulling back and letting go of the button (think angry birds)
		-You must hold the puck with the right mouse, pull the mouse back, then let go of the right mouse button
	(3) The become player button will promote a spectator to a player only if there is room for another player 
	(4) the reset players button resets the players, allowing a spectator to become a player again
		-It sets everyone to spectator; If become player dosnt work, just click reset players
	(5) to start a new game, disconnect all clients and reconnect the browser using the server link
Issues:
	Nel said this is ok: Nels framwork is bugged, you must have the screen centered in the top left hand corner mouse clicks to work
	Other issue: on some operating systems collitions will bug and be animated incorrectly, tested to work on virtual box (download the image for the course xubuntu)
Please note: 
	If a stone has nowhere to go, it can pass "over" other stones if moving very fast, this is intentional
	This is supposed to be stones piling on top of each other
	if you slam a pile of stone hard enough, they will move "over" each other
	This simulates the 3-D space of the curling rink, and prevents stones from becoming immobile
	Stones will otherwise collide like normal and bounce off each other

	to restart a game simply reload a browser and move a puck
	
	
