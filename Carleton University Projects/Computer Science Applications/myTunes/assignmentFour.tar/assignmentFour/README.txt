This assignment, code, and other files are the work of: Connor Raymond Stewart (101041125) & Louis D. Nel

-Which extraction command should be used to uncompress your assignment files.
	tar -xvf assignmentFour.tar

-Which g++ compiler or make command should be executed to compile your code.
	2 steps:
		Type: make
		Type: ./mytunes

-Instructions on what script, or scripts, to run to demonstrate your testing.
	2 scripts: Type .read and input the file names to exicute a script
		insert_beatles_tracks_rev1.txt - initalizes the beatles database (it should also be automatically initalized upon program start)
		testingScript.txt - tests the follow commands functional requirements