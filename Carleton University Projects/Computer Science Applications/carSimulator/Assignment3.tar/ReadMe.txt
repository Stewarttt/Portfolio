Name: Connor Raymond Stewart
Student Number: 101041125
Carleton Email: connorrstewart@cmail.carleton.ca
Source File Names:
    parkingSimulatorTemplate.c
	simulator2.c
Compile Instructions: Open the Terminal to the directory of the source files and enter
	parkingSimulatorTemplate:
		gcc -Wall -o parkingSimulatorTemplate -std=c99 parkingSimulatorTemplate.c
		./parkingSimulatorTemplate
	simulator2:
		gcc -Wall -o simulator2 -std=c99 simulator2.c
		./simulator2
Output:
	The output generated follows the requests in the assignment specifications
