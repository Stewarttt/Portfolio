Name: Connor Stewart
Student Number: 101041125
Source Files Submitted:
    textToBinary.c
    healthAssessment.c
    makefile
    ReadMe.txt
    absenteeism.txt
instructions:
    to start, open the terminal to the current directory and type:
        make all
    this will compile the files.
    next type:
        ./textToBinary
    this will create the binary file, to verify the binary file is of correct size type:
        ls -l
    next type:
        ./healthAssessment
    this will output the formated information from the binary file into the terminal shell, as
        the assignment specifications outline
    to clean up the compiled files, or to clean up the binary file produced, type:
        make clean
